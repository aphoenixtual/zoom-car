package com.project.api.repository;

public class Repository {

}
