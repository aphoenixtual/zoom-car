package com.project.api.entity;

public class TestEntity {

}
