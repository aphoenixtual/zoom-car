import React from 'react'

function Footer() {
    return (
        <div style={{height:"1em", width:"100%", background:"#4E4E50", marginTop:100}}>
            
        </div>
    )
}

export default Footer
